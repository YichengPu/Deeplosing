'use strict';

// Define the `phonecatApp` module
angular.module('marketapp', [
  'ngRoute',
  'postDetail',
  'postDiv'
]);
