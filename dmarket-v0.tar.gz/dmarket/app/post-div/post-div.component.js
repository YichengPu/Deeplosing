'use strict';

angular.
  module('postDiv').
  component('postDiv', {
  templateUrl:'post-div/post-div.template.html',
  controller: function PostController($http) {
    var self=this;
    $http.get('posts/allposts.json').then(function(response){
      self.posts=response.data;
    });
    }
  }
);
