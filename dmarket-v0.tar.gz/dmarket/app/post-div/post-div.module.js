'use strict';

// Define the `phoneList` module
angular.module('postDiv', []);
